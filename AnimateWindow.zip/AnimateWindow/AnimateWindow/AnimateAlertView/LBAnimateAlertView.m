//
//  LBAnimateAlertView.m
//  iosfighterlb4
//
//  Created by 卢祥庭 on 12/12/15.
//  Copyright © 2015 37wan. All rights reserved.
//

#import "LBAnimateAlertView.h"
#import <QuartzCore/QuartzCore.h>

CGFloat const kLBFadeInAnimationDuration = 0.3;
CGFloat const kLBTransformPart1AnimationDuration = 0.2;
CGFloat const kLBTransformPart2AnimationDuration = 0.1;
CGFloat const kLBDefaultCloseButtonPadding = 17.0;

NSString* const LBAnimateAlertViewGradientViewTapped   = @"LBAnimateAlertViewGradientViewTapped";

NSString* const LBAnimateAlertViewWillShowNotification = @"LBAnimateAlertViewWillShowNotification";
NSString* const LBAnimateAlertViewDidShowNotification  = @"LBAnimateAlertViewDidShowNotification";
NSString* const LBAnimateAlertViewWillHideNotification = @"LBAnimateAlertViewWillHideNotification";
NSString* const LBAnimateAlertViewDidHideNotification  = @"LBAnimateAlertViewDidHideNotification";


#pragma mark - LBAnimateAlertGradientView

/***
 *   LBAnimateAlertGradientView, dim Layer.
 */

@interface LBAnimateAlertGradientView : UIView

@end


@implementation LBAnimateAlertGradientView

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    [[NSNotificationCenter defaultCenter] postNotificationName:LBAnimateAlertViewGradientViewTapped object:nil];
}

- (void)drawRect:(CGRect)rect
{
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    if([[LBAnimateAlertView sharedInstance] backgroundDisplayStyle] == LBAnimateAlertViewBackgroundDisplayStyleSolid)
    {
        [[UIColor colorWithWhite:0 alpha:0.55] set];
        CGContextFillRect(context, self.bounds);
    }
    else
    {
        //阴暗的遮挡层
        CGContextSaveGState(context);
        size_t gradLocationsNum = 2;
        CGFloat gradLocations[2] = {0.0f, 1.0f};
        CGFloat gradColors[8] = {0, 0, 0, 0.3, 0, 0, 0, 0.8};
        CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
        CGGradientRef gradient = CGGradientCreateWithColorComponents(colorSpace, gradColors, gradLocations, gradLocationsNum);
        CGColorSpaceRelease(colorSpace), colorSpace = NULL;
        CGPoint gradCenter= CGPointMake(round(CGRectGetMidX(self.bounds)), round(CGRectGetMidY(self.bounds)));
        CGFloat gradRadius = MAX(CGRectGetWidth(self.bounds), CGRectGetHeight(self.bounds));
        CGContextDrawRadialGradient(context, gradient, gradCenter, 0, gradCenter, gradRadius, kCGGradientDrawsAfterEndLocation);
        CGGradientRelease(gradient), gradient = NULL;
        CGContextRestoreGState(context);
    }
}

@end



#pragma mark - LBAnimateAlertContainerView

/**
 *  LBAnimateAlertContainerView , Content view.
 */

@interface LBAnimateAlertContainerView : UIView

@property (weak,   nonatomic) CALayer* styleLayer;
@property (strong, nonatomic) UIColor* alertViewBackgroundColor;

@end


@implementation LBAnimateAlertContainerView

- (instancetype)initWithFrame:(CGRect)frame
{
    if(!(self = [super initWithFrame:frame]))
    {
        return nil;
    }
    
    CALayer* styleLayer = [[CALayer alloc] init];
    styleLayer.cornerRadius = 4;
    styleLayer.shadowColor= [[UIColor blackColor] CGColor];
    styleLayer.shadowOffset = CGSizeMake(0, 0);
    styleLayer.shadowOpacity = 0.5;
    styleLayer.borderWidth = 0.5;
    styleLayer.borderColor = [UIColor colorWithWhite:0 alpha:0.5].CGColor;
    styleLayer.frame = CGRectInset(self.bounds, 12, 12);
    [self.layer addSublayer:styleLayer];
    self.styleLayer = styleLayer;
    
    return self;
}

- (void)setAlertViewBackgroundColor:(UIColor *)alertViewBackgroundColor
{
    if (_alertViewBackgroundColor != alertViewBackgroundColor)
    {
        _alertViewBackgroundColor = alertViewBackgroundColor;
        self.styleLayer.backgroundColor = alertViewBackgroundColor.CGColor;
    }
}


@end



#pragma mark - LBAnimateAlertViewController

/**
 *  LBAnimateAlertViewController, the ViewController whitch hold the dim Layer.
 */

@interface LBAnimateAlertViewController : UIViewController

@property (weak, nonatomic) LBAnimateAlertGradientView* styleView;

@end


@implementation LBAnimateAlertViewController

- (void)loadView
{
    self.view = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor clearColor];
    self.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    
    LBAnimateAlertGradientView* styleView = [[LBAnimateAlertGradientView alloc] initWithFrame:self.view.bounds];
    styleView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    styleView.opaque = NO;
    [self.view addSubview:styleView];
    self.styleView = styleView;
}

- (BOOL)shouldAutorotate
{
    return [[LBAnimateAlertView sharedInstance] shouldRotate];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation
{
    return [[LBAnimateAlertView sharedInstance] shouldRotate];
}

@end



#pragma mark - LBAnimateAlertView

/***
 *   LBAnimateAlertView . Singleton pattern , extensible.
 */

@interface LBAnimateAlertView ()

// Prepare For releaseing.
@property (nonatomic, strong) UIWindow* window;
@property (nonatomic,   weak) UIView* contentView;
@property (nonatomic, strong) UIViewController* contentViewController;
@property (nonatomic,   weak) LBAnimateAlertContainerView* containerView;
@property (nonatomic,   weak) LBAnimateAlertViewController* viewController;

@end

@implementation LBAnimateAlertView

+ (instancetype)sharedInstance
{
    static id sharedInstance;
    static dispatch_once_t once;
    
    dispatch_once(&once, ^{
        sharedInstance = [[[self class] alloc] init];
    });
    return sharedInstance;
}

- (instancetype)init
{
    if(!(self = [super init]))
    {
        return nil;
    }
    
    self.shouldRotate = YES;
    self.tapOutsideToDismiss  = YES;
    self.animateWhenDismissed = YES;
    self.alertViewBackgroundColor = [UIColor whiteColor];
    
    return self;
}

- (void)setAlertViewBackgroundColor:(UIColor *)alertViewBackgroundColor
{
    if (_alertViewBackgroundColor != alertViewBackgroundColor)
    {
        _alertViewBackgroundColor = alertViewBackgroundColor;
        self.containerView.alertViewBackgroundColor = alertViewBackgroundColor;
    }
}

- (void)showWithContentView:(UIView *)contentView
{
    [self showWithContentView:contentView andAnimated:YES];
}

- (void)showWithContentViewController:(UIViewController *)contentViewController
{
    [self showWithContentViewController:contentViewController andAnimated:YES];
}

- (void)showWithContentViewController:(UIViewController *)contentViewController andAnimated:(BOOL)animated
{
    self.contentViewController = contentViewController;
    [self showWithContentView:contentViewController.view andAnimated:YES];
}

- (void)showWithContentView:(UIView *)contentView andAnimated:(BOOL)animated
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.window.opaque = NO;
    
    LBAnimateAlertViewController* viewController = [[LBAnimateAlertViewController alloc] init];
    self.window.rootViewController = viewController;
    self.viewController = viewController;
    
    CGFloat padding = 12;
    CGRect containerViewRect = CGRectInset(contentView.bounds, -padding, -padding);
    containerViewRect.origin.x = containerViewRect.origin.y = 0;
    
    containerViewRect.origin.x = round(CGRectGetMidX(self.window.bounds)-CGRectGetMidX(containerViewRect));
    containerViewRect.origin.y = round(CGRectGetMidY(self.window.bounds)-CGRectGetMidY(containerViewRect));
    
    LBAnimateAlertContainerView* containerView = [[LBAnimateAlertContainerView alloc] initWithFrame:containerViewRect];
    containerView.alertViewBackgroundColor = self.alertViewBackgroundColor;
    containerView.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin  |
                                     UIViewAutoresizingFlexibleRightMargin |
                                     UIViewAutoresizingFlexibleTopMargin   |
                                     UIViewAutoresizingFlexibleBottomMargin;
    
    containerView.layer.rasterizationScale = [[UIScreen mainScreen] scale];
    contentView.frame = (CGRect){padding, padding, contentView.bounds.size};
    [containerView addSubview:contentView];
    [viewController.view addSubview:containerView];
    self.containerView = containerView;
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(tapCloseAction:)
                                                 name:LBAnimateAlertViewGradientViewTapped object:nil];
    
    dispatch_async(dispatch_get_main_queue(), ^{
    
        [[NSNotificationCenter defaultCenter] postNotificationName:LBAnimateAlertViewWillShowNotification object:self];
        [self.window makeKeyAndVisible];
        
        if (animated)
        {
            viewController.styleView.alpha = 0;
            
            [UIView animateWithDuration:kLBFadeInAnimationDuration animations:^{
                viewController.styleView.alpha = 1;
            }];
            
            containerView.alpha = 0;
            containerView.layer.shouldRasterize = YES;
            containerView.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.4, 0.4);
            
            [UIView animateWithDuration:kLBTransformPart1AnimationDuration animations:^{
                
                containerView.alpha = 1;
                containerView.transform = CGAffineTransformScale(CGAffineTransformIdentity, 1.1, 1.1);
                
            } completion:^(BOOL finished){
            
                [UIView animateWithDuration:kLBTransformPart2AnimationDuration delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
                
                    containerView.alpha = 1;
                    containerView.transform = CGAffineTransformScale(CGAffineTransformIdentity, 1, 1);
                
                } completion:^(BOOL alsoFinised){
                
                    containerView.layer.shouldRasterize = NO;
                    [[NSNotificationCenter defaultCenter] postNotificationName:LBAnimateAlertViewDidShowNotification object:self];

                }];
            
            }];
        }
    
    });
    
}


- (void)cancelButtonClicked:(id)sender
{
    [self hideAnimated:self.animateWhenDismissed];
}

- (void)tapCloseAction:(id)sender
{
    if(self.tapOutsideToDismiss)
    {
        [self hideAnimated:self.animateWhenDismissed];
    }
}

- (void)hide
{
    [self hideAnimated:YES];
}

- (void)hideWithCompletionBlock:(void(^)())completion
{
    [self hideAnimated:YES withCompletionBlock:completion];
}

- (void)hideAnimated:(BOOL)animated
{
    [self hideAnimated:animated withCompletionBlock:nil];
}

- (void)hideAnimated:(BOOL)animated withCompletionBlock:(void(^)())completion
{
    if(!animated)
    {
        [self cleanup];
        return;
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter] postNotificationName:LBAnimateAlertViewWillHideNotification object:self];
        
        [UIView animateWithDuration:kLBFadeInAnimationDuration animations:^{
            
            self.viewController.styleView.alpha = 0;
        }];
        
        self.containerView.layer.shouldRasterize = YES;
        
        [UIView animateWithDuration:kLBTransformPart2AnimationDuration animations:^{
            
            self.containerView.transform = CGAffineTransformScale(CGAffineTransformIdentity, 1.1, 1.1);
            
        } completion:^(BOOL finished){
            
            [UIView animateWithDuration:kLBTransformPart1AnimationDuration delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
                
                self.containerView.alpha = 0;
                self.containerView.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.4, 0.4);
                
            } completion:^(BOOL finished2){
                
                [self cleanup];
                
                if(completion)
                {
                    completion();
                }
                [[NSNotificationCenter defaultCenter] postNotificationName:LBAnimateAlertViewDidHideNotification object:self];
            }];
        }];
    });
}

- (void)cleanup
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];

    [self.containerView removeFromSuperview];
    [self.window removeFromSuperview];

    self.window = nil;
    self.contentViewController = nil;

    [[[[UIApplication sharedApplication] delegate] window] makeKeyWindow];
}


- (void)dealloc
{
    [self cleanup];
}


#pragma Extended.

- (void)showFrame:(CGRect)frame image:(UIImage *)image name:(NSString *)name content:(NSString *)content
{
    UIView* containView = [[UIView alloc] init];
    [containView setBackgroundColor:[UIColor colorWithRed:arc4random_uniform(255)/255.0 green:arc4random_uniform(255)/255.0 blue:arc4random_uniform(255)/255.0 alpha:1]];
    [containView setFrame:frame];
    
    UIImageView* gameImgView = [[UIImageView alloc] init];
    [gameImgView setFrame:CGRectMake(0, 0, 50, 50)];
    [gameImgView setCenter:CGPointMake(40, 40)];
    [gameImgView setImage:image];
    [containView addSubview:gameImgView];
    
    UILabel* gameLabel = [[UILabel alloc] init];
    [gameLabel setFrame:CGRectMake(0, 0, 100, 50)];
    [gameLabel setCenter:CGPointMake(containView.center.x, 35)];
    [gameLabel setFont:[UIFont systemFontOfSize:18.0f]];
    [gameLabel setTextColor:[UIColor whiteColor]];
    [gameLabel setTextAlignment:NSTextAlignmentCenter];
    [gameLabel setText:name];
    [containView addSubview:gameLabel];
    
    UIButton* cancelButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [cancelButton setFrame:CGRectMake(0, 0, 22, 22)];
    [cancelButton setCenter:CGPointMake(containView.frame.size.width - 35, 35)];
    [cancelButton setBackgroundImage:[UIImage imageNamed:@"close.png"]
                            forState:UIControlStateNormal];
    [cancelButton addTarget:self action:@selector(cancelButtonClicked:)
           forControlEvents:UIControlEventTouchUpInside];
    [containView addSubview:cancelButton];
    
    UITextView* contentTextView = [[UITextView alloc] init];
    [contentTextView setFrame:CGRectMake(0, 100,
                                         containView.frame.size.width,
                                         containView.frame.size.height - 100)];
    contentTextView.editable = NO;
    [contentTextView setText:content];
    [containView addSubview:contentTextView];
    
    [self showWithContentView:containView andAnimated:YES];
}

@end











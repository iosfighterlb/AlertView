//
//  LBAnimateAlertView.h
//  iosfighterlb4
//
//  Created by 卢祥庭 on 12/12/15.
//  Copyright © 2015 37wan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

extern NSString* const LBAnimateAlertViewWillShowNotification;
extern NSString* const LBAnimateAlertViewDidShowNotification;
extern NSString* const LBAnimateAlertViewWillHideNotification;
extern NSString* const LBAnimateAlertViewDidHideNotification;

typedef NS_ENUM(NSUInteger, LBAnimateAlertViewBackgroundDisplayStyle)
{
    LBAnimateAlertViewBackgroundDisplayStyleGradient,
    LBAnimateAlertViewBackgroundDisplayStyleSolid
};

@interface LBAnimateAlertView : NSObject

@property (nonatomic) BOOL tapOutsideToDismiss;                     //点击内容框外是否dismiss

@property (nonatomic) BOOL animateWhenDismissed;                    //dismiss的时候是否animate

@property (nonatomic, strong) UIColor* alertViewBackgroundColor;

@property (nonatomic) LBAnimateAlertViewBackgroundDisplayStyle backgroundDisplayStyle;

@property (nonatomic) BOOL shouldRotate;

+ (instancetype)sharedInstance;

/***
 *   Show and Hide. Nested.
 *
 *   @param contentView , contentViewController , complete block operaiton , and Animated.
 */

- (void)showWithContentView:(UIView *)contentView;

- (void)showWithContentView:(UIView *)contentView andAnimated:(BOOL)animated;

- (void)showWithContentViewController:(UIViewController *)contentViewController;

- (void)showWithContentViewController:(UIViewController *)contentViewController andAnimated:(BOOL)animated;

- (void)hide;

- (void)hideWithCompletionBlock:(void(^)())completion;

- (void)hideAnimated:(BOOL)animated;

- (void)hideAnimated:(BOOL)animated withCompletionBlock:(void(^)())completion;

- (void)showFrame:(CGRect)frame image:(UIImage* )image name:(NSString* )name content:(NSString* )content;


@end

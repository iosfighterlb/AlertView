//
//  ViewController.h
//  AnimateWindow
//
//  Created by 卢祥庭 on 7/18/16.
//  Copyright © 2016 com.37wan.37SYTechnology. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (nonatomic, weak) IBOutlet UIButton* button;

- (IBAction) buttonClicked:(id)sender;

@end





//
//  ViewController.m
//  AnimateWindow
//
//  Created by 卢祥庭 on 7/18/16.
//  Copyright © 2016 com.37wan.37SYTechnology. All rights reserved.
//

#import "ViewController.h"

#import "LBAnimateAlertView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor colorWithRed:arc4random_uniform(255)/255.0 green:arc4random_uniform(255)/255.0 blue:arc4random_uniform(255)/255.0 alpha:1]];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (IBAction)buttonClicked:(id)sender
{
    CGRect frame = CGRectMake(0, 0, 250, 200);
    NSString* contentStr = @"长夜将至，我从今开始守望，至死方休。我将不娶妻、不封地、不生子。我将不戴宝冠，不争荣宠。我将尽忠职守，生死於斯。我是黑暗中的利剑，长城上的守卫。我将生命与荣耀献给守夜人，今夜如此，夜夜皆然";
    
    //我是抵御寒冷的烈焰，破晓时分的光线，唤醒眠者的号角，守护王国的坚盾。
    
    [[LBAnimateAlertView sharedInstance] showFrame:frame image:[UIImage imageNamed:@"lufy.jpg"] name:@"守夜人誓词" content:contentStr];
}

@end
